<footer class="mt-4" style="background-color: #333; color: #fff; width: 100%;">
    <div class="container py-4">
        <div class="row">
            <div class="col-md-4">
                <h5>About Us</h5>
                <p>We are committed to providing quality products and services to our customers.</p>
            </div>
            <div class="col-md-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white">Home</a></li>
                    <li><a href="#" class="text-white">Services</a></li>
                    <li><a href="#" class="text-white">Contact</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Follow Us</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white">Facebook</a></li>
                    <li><a href="#" class="text-white">Twitter</a></li>
                    <li><a href="#" class="text-white">Instagram</a></li>
                </ul>
            </div>
        </div>
        <div class="text-center mt-3">&copy; 2024. All Rights Reserved.</div>
    </div>
</footer>
